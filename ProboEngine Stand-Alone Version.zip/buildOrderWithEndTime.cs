﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
	public class buildOrderWithEndTime
    {
        public double endTime { get; set; }
        public List<buildOrderEntry> buildOrder {get;set;}
        public buildOrderWithEndTime(double myEndTime, List<buildOrderEntry> myBuildOrder)
        {
            endTime = myEndTime;
            buildOrder = myBuildOrder;
        }
    }
}
